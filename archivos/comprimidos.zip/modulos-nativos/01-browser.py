import webbrowser

print("producto encontrado!")
webbrowser.open("https://brianbentancourt.com")
