import random

print(
    random.random(),
    random.randint(1, 100),
    random.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9])
)
